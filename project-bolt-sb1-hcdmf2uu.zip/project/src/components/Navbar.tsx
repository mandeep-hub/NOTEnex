import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Upload, HelpCircle, Home, Search, ChevronDown, Menu, X } from 'lucide-react';

function Navbar() {
  const [showFacultyDropdown, setShowFacultyDropdown] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const subjects = [
    'Physics',
    'Chemistry',
    'Biology',
    'Mathematics',
    'Computer Science',
    'English',
    'Economics'
  ];

  return (
    <nav className="bg-gray-900 shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="h-6 w-6 text-blue-400" />
            <span className="text-xl font-bold text-white">NoteNexus</span>
          </Link>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="text-gray-300 hover:text-white"
            >
              {showMobileMenu ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>

          {/* Desktop navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <div className="relative">
              <button
                onClick={() => setShowSearch(!showSearch)}
                className="text-gray-300 hover:text-blue-400 transition-colors duration-200"
              >
                <Search className="h-5 w-5" />
              </button>

              {showSearch && (
                <div className="absolute right-0 top-full mt-2 w-72 bg-gray-800 rounded-lg shadow-xl p-4 z-50 border border-gray-700">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search notes..."
                      className="w-full pl-10 pr-4 py-2 bg-gray-700 border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-gray-400"
                    />
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  </div>
                </div>
              )}
            </div>

            <Link to="/" className="flex items-center space-x-1 text-gray-300 hover:text-blue-400 transition-colors duration-200">
              <Home className="h-5 w-5" />
              <span>Home</span>
            </Link>
            <Link to="/notes" className="flex items-center space-x-1 text-gray-300 hover:text-blue-400 transition-colors duration-200">
              <BookOpen className="h-5 w-5" />
              <span>Notes</span>
            </Link>
            <Link to="/upload" className="flex items-center space-x-1 text-gray-300 hover:text-blue-400 transition-colors duration-200">
              <Upload className="h-5 w-5" />
              <span>Upload</span>
            </Link>
            <Link to="/questions" className="flex items-center space-x-1 text-gray-300 hover:text-blue-400 transition-colors duration-200">
              <HelpCircle className="h-5 w-5" />
              <span>Questions</span>
            </Link>

            <div className="relative">
              <button
                className="flex items-center space-x-1 text-gray-300 hover:text-blue-400 transition-colors duration-200"
                onMouseEnter={() => setShowFacultyDropdown(true)}
                onMouseLeave={() => setShowFacultyDropdown(false)}
              >
                <span>Subjects</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              {showFacultyDropdown && (
                <div
                  className="absolute top-full right-0 mt-1 w-48 bg-gray-800 rounded-lg shadow-xl py-2 z-50 border border-gray-700"
                  onMouseEnter={() => setShowFacultyDropdown(true)}
                  onMouseLeave={() => setShowFacultyDropdown(false)}
                >
                  {subjects.map((subject) => (
                    <Link
                      key={subject}
                      to={`/notes/subject/${subject.toLowerCase().replace(' ', '-')}`}
                      className="block px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-blue-400 transition-colors duration-200"
                    >
                      {subject}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {showMobileMenu && (
          <div className="md:hidden bg-gray-800 py-4 px-2 rounded-lg mt-2">
            <div className="flex flex-col space-y-3">
              <Link 
                to="/" 
                className="flex items-center space-x-2 text-gray-300 hover:text-blue-400 px-3 py-2 rounded-md hover:bg-gray-700"
                onClick={() => setShowMobileMenu(false)}
              >
                <Home className="h-5 w-5" />
                <span>Home</span>
              </Link>
              <Link 
                to="/notes" 
                className="flex items-center space-x-2 text-gray-300 hover:text-blue-400 px-3 py-2 rounded-md hover:bg-gray-700"
                onClick={() => setShowMobileMenu(false)}
              >
                <BookOpen className="h-5 w-5" />
                <span>Notes</span>
              </Link>
              <Link 
                to="/upload" 
                className="flex items-center space-x-2 text-gray-300 hover:text-blue-400 px-3 py-2 rounded-md hover:bg-gray-700"
                onClick={() => setShowMobileMenu(false)}
              >
                <Upload className="h-5 w-5" />
                <span>Upload</span>
              </Link>
              <Link 
                to="/questions" 
                className="flex items-center space-x-2 text-gray-300 hover:text-blue-400 px-3 py-2 rounded-md hover:bg-gray-700"
                onClick={() => setShowMobileMenu(false)}
              >
                <HelpCircle className="h-5 w-5" />
                <span>Questions</span>
              </Link>
              
              <div className="px-3 py-2">
                <div className="font-medium text-gray-300 mb-2">Subjects</div>
                <div className="pl-2 space-y-1">
                  {subjects.map((subject) => (
                    <Link
                      key={subject}
                      to={`/notes/subject/${subject.toLowerCase().replace(' ', '-')}`}
                      className="block py-1 text-gray-400 hover:text-blue-400"
                      onClick={() => setShowMobileMenu(false)}
                    >
                      {subject}
                    </Link>
                  ))}
                </div>
              </div>
              
              <div className="relative px-3 py-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <input
                    type="text"
                    placeholder="Search notes..."
                    className="w-full pl-10 pr-4 py-2 bg-gray-700 border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-gray-400"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navbar;