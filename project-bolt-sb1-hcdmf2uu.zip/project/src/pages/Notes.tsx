import React, { useState, useEffect } from 'react';
import { Search, Filter, FileText, Download, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

// Define types
interface Note {
  id: number;
  title: string;
  subject: string;
  class_level: string;
  author: string;
  upload_date: string;
  downloads: number;
  file_url: string;
  subtopic?: string;
}

function Notes() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedClassLevel, setSelectedClassLevel] = useState('all');
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  const subjects = ['All', 'Physics', 'Chemistry', 'Biology', 'Mathematics', 'Computer Science', 'English', 'Economics'];
  const classLevels = ['All', '+2 First Year', '+2 Second Year', 'Bachelor First Year', 'Bachelor Second Year', 'Bachelor Third Year', 'Bachelor Fourth Year', 'Masters'];

  // Sample notes data - in a real app, this would come from Supabase
  const sampleNotes: Note[] = [
    {
      id: 1,
      title: 'Mechanics and Properties of Matter',
      subject: 'Physics',
      class_level: '+2 First Year',
      author: 'Dr. Rajesh Sharma',
      upload_date: '2024-03-10',
      downloads: 125,
      file_url: '#',
      subtopic: 'Mechanics'
    },
    {
      id: 2,
      title: 'Electromagnetism and Modern Physics',
      subject: 'Physics',
      class_level: '+2 Second Year',
      author: 'Prof. Anita Poudel',
      upload_date: '2024-03-15',
      downloads: 98,
      file_url: '#',
      subtopic: 'Electromagnetism'
    },
    {
      id: 3,
      title: 'Organic Chemistry Fundamentals',
      subject: 'Chemistry',
      class_level: '+2 First Year',
      author: 'Dr. Sunil Thapa',
      upload_date: '2024-02-28',
      downloads: 112,
      file_url: '#',
      subtopic: 'Organic Chemistry'
    },
    {
      id: 4,
      title: 'Calculus and Analytical Geometry',
      subject: 'Mathematics',
      class_level: 'Bachelor First Year',
      author: 'Prof. Binod Adhikari',
      upload_date: '2024-03-05',
      downloads: 145,
      file_url: '#',
      subtopic: 'Calculus'
    },
    {
      id: 5,
      title: 'Data Structures and Algorithms',
      subject: 'Computer Science',
      class_level: 'Bachelor Second Year',
      author: 'Dr. Manisha KC',
      upload_date: '2024-03-12',
      downloads: 167,
      file_url: '#',
      subtopic: 'Data Structures'
    },
    {
      id: 6,
      title: 'Quantum Mechanics',
      subject: 'Physics',
      class_level: 'Bachelor Third Year',
      author: 'Dr. Prakash Ghimire',
      upload_date: '2024-02-20',
      downloads: 89,
      file_url: '#',
      subtopic: 'Quantum Physics'
    }
  ];

  useEffect(() => {
    // Simulate fetching data from Supabase
    setLoading(true);
    setTimeout(() => {
      setNotes(sampleNotes);
      setLoading(false);
    }, 1000);

    // In a real app, you would fetch from Supabase like this:
    // const fetchNotes = async () => {
    //   try {
    //     const { data, error } = await supabase
    //       .from('notes')
    //       .select('*');
    //     
    //     if (error) throw error;
    //     if (data) setNotes(data);
    //   } catch (error) {
    //     console.error('Error fetching notes:', error);
    //   } finally {
    //     setLoading(false);
    //   }
    // };
    // 
    // fetchNotes();
  }, []);

  // Filter notes based on search term, subject, and class level
  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          note.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || note.subject === selectedSubject;
    const matchesClassLevel = selectedClassLevel === 'all' || note.class_level === selectedClassLevel;
    
    return matchesSearch && matchesSubject && matchesClassLevel;
  });

  const handleDownload = (note: Note) => {
    // In a real app, this would download the PDF file
    alert(`Downloading ${note.title}`);
  };

  const handleViewPdf = (note: Note) => {
    // In a real app, this would open the PDF viewer
    alert(`Viewing ${note.title}`);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Study Notes</h1>
        <p className="text-gray-600">Browse and download study materials organized by subject and class level</p>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search notes by title or author..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-400 mr-2" />
              <select
                className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
              >
                {subjects.map((subject) => (
                  <option key={subject} value={subject === 'All' ? 'all' : subject}>
                    {subject}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex items-center">
              <select
                className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={selectedClassLevel}
                onChange={(e) => setSelectedClassLevel(e.target.value)}
              >
                {classLevels.map((level) => (
                  <option key={level} value={level === 'All' ? 'all' : level}>
                    {level}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : filteredNotes.length === 0 ? (
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No notes found</h3>
          <p className="text-gray-600">Try adjusting your search or filters</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {filteredNotes.map((note) => (
            <div key={note.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="flex flex-col md:flex-row justify-between">
                <div className="mb-4 md:mb-0">
                  <div className="flex items-center mb-2">
                    <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium mr-2">
                      {note.subject}
                    </span>
                    <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                      {note.class_level}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{note.title}</h3>
                  <p className="text-gray-600">Author: {note.author}</p>
                  <p className="text-gray-600">Uploaded: {note.upload_date}</p>
                  <p className="text-gray-600">{note.downloads} downloads</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <button 
                    onClick={() => handleViewPdf(note)}
                    className="flex items-center justify-center px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    View PDF
                  </button>
                  <button 
                    onClick={() => handleDownload(note)}
                    className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-12 bg-blue-50 p-6 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Subject Syllabi</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjects.filter(subject => subject !== 'All').map((subject) => (
            <div key={subject} className="bg-white p-4 rounded-md shadow hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-lg mb-2">{subject}</h3>
              <p className="text-sm text-gray-600 mb-3">Complete syllabus and study materials</p>
              <Link 
                to={`/notes/subject/${subject.toLowerCase().replace(' ', '-')}`}
                className="text-blue-600 text-sm font-medium hover:underline"
              >
                View all {subject} notes →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Notes;