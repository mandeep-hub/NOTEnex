import React, { useState } from 'react';
import { MessageCircle } from 'lucide-react';

function Questions() {
  const [questions] = useState([
    {
      id: 1,
      title: 'How to implement quicksort?',
      author: 'John Doe',
      date: '2024-03-10',
      content: 'I am having trouble understanding the quicksort algorithm. Can someone explain the partition step?',
      answers: [
        {
          id: 1,
          author: 'Jane Smith',
          content: 'The partition step involves choosing a pivot and...',
          date: '2024-03-10',
        }
      ]
    }
  ]);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">Questions & Discussions</h2>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Ask Question
        </button>
      </div>

      <div className="space-y-6">
        {questions.map((question) => (
          <div key={question.id} className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">{question.title}</h3>
            <p className="text-gray-600 mb-4">{question.content}</p>
            
            <div className="flex items-center text-sm text-gray-500 mb-4">
              <span>Posted by {question.author}</span>
              <span className="mx-2">•</span>
              <span>{question.date}</span>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center mb-4">
                <MessageCircle className="h-5 w-5 text-gray-400 mr-2" />
                <span className="font-medium">{question.answers.length} Answers</span>
              </div>

              {question.answers.map((answer) => (
                <div key={answer.id} className="bg-gray-50 p-4 rounded-lg mb-4">
                  <p className="text-gray-800 mb-2">{answer.content}</p>
                  <div className="text-sm text-gray-500">
                    <span>Answered by {answer.author}</span>
                    <span className="mx-2">•</span>
                    <span>{answer.date}</span>
                  </div>
                </div>
              ))}

              <div className="mt-4">
                <textarea
                  placeholder="Write your answer..."
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                />
                <button className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Post Answer
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Questions;