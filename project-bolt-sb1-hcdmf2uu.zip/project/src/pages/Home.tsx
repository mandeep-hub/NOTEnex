import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Upload, HelpCircle } from 'lucide-react';

function Home() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to NoteNexus</h1>
        <p className="text-lg text-gray-600">Share knowledge, learn together, and excel in your studies</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <Link to="/notes" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex flex-col items-center text-center">
            <BookOpen className="h-12 w-12 text-blue-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Browse Notes</h2>
            <p className="text-gray-600">Access study materials from various faculties</p>
          </div>
        </Link>

        <Link to="/upload" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex flex-col items-center text-center">
            <Upload className="h-12 w-12 text-green-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Upload Notes</h2>
            <p className="text-gray-600">Share your knowledge with others</p>
          </div>
        </Link>

        <Link to="/questions" className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
          <div className="flex flex-col items-center text-center">
            <HelpCircle className="h-12 w-12 text-purple-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Ask Questions</h2>
            <p className="text-gray-600">Get help from the community</p>
          </div>
        </Link>
      </div>

      <div className="mt-16 bg-blue-50 p-8 rounded-lg">
        <h2 className="text-2xl font-semibold mb-4 text-center">Featured Notes</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-4 rounded-md shadow">
            <h3 className="font-semibold">Computer Science Fundamentals</h3>
            <p className="text-sm text-gray-600">Introduction to algorithms and data structures</p>
          </div>
          <div className="bg-white p-4 rounded-md shadow">
            <h3 className="font-semibold">Engineering Mathematics</h3>
            <p className="text-sm text-gray-600">Calculus and linear algebra basics</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;