import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FileText, Download, Eye, ArrowLeft, BookOpen } from 'lucide-react';
import PdfViewer from '../components/PdfViewer';

interface Note {
  id: number;
  title: string;
  subject: string;
  class_level: string;
  author: string;
  upload_date: string;
  downloads: number;
  file_url: string;
  description?: string;
  subtopic?: string;
}

interface SubtopicGroup {
  name: string;
  notes: Note[];
}

function SubjectDetail() {
  const { subject } = useParams<{ subject: string }>();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedClassLevel, setSelectedClassLevel] = useState('all');
  const [viewingPdf, setViewingPdf] = useState<Note | null>(null);
  const [subtopics, setSubtopics] = useState<SubtopicGroup[]>([]);
  const [showSubtopics, setShowSubtopics] = useState(false);
  
  const classLevels = ['All', '+2 First Year', '+2 Second Year', 'Bachelor First Year', 'Bachelor Second Year', 'Bachelor Third Year', 'Bachelor Fourth Year', 'Masters'];

  // Sample notes data - in a real app, this would come from Supabase
  const sampleNotes: Note[] = [
    {
      id: 1,
      title: 'Mechanics and Properties of Matter',
      subject: 'Physics',
      class_level: '+2 First Year',
      author: 'Dr. Rajesh Sharma',
      upload_date: '2024-03-10',
      downloads: 125,
      file_url: 'https://example.com/sample.pdf',
      description: 'Comprehensive notes covering Newton\'s laws of motion, gravitation, work, energy, and properties of matter.',
      subtopic: 'Mechanics'
    },
    {
      id: 2,
      title: 'Electromagnetism and Modern Physics',
      subject: 'Physics',
      class_level: '+2 Second Year',
      author: 'Prof. Anita Poudel',
      upload_date: '2024-03-15',
      downloads: 98,
      file_url: 'https://example.com/sample.pdf',
      description: 'Detailed notes on electric fields, magnetic fields, electromagnetic induction, and introduction to modern physics.',
      subtopic: 'Electromagnetism'
    },
    {
      id: 3,
      title: 'Waves and Oscillations',
      subject: 'Physics',
      class_level: '+2 First Year',
      author: 'Dr. Sunil Thapa',
      upload_date: '2024-02-28',
      downloads: 112,
      file_url: 'https://example.com/sample.pdf',
      description: 'Complete study material on simple harmonic motion, damped and forced oscillations, and wave phenomena.',
      subtopic: 'Waves'
    },
    {
      id: 4,
      title: 'Thermodynamics',
      subject: 'Physics',
      class_level: 'Bachelor First Year',
      author: 'Prof. Binod Adhikari',
      upload_date: '2024-03-05',
      downloads: 145,
      file_url: 'https://example.com/sample.pdf',
      description: 'Comprehensive notes on laws of thermodynamics, entropy, and thermodynamic processes.',
      subtopic: 'Thermodynamics'
    },
    {
      id: 5,
      title: 'Quantum Mechanics',
      subject: 'Physics',
      class_level: 'Bachelor Second Year',
      author: 'Dr. Manisha KC',
      upload_date: '2024-03-12',
      downloads: 167,
      file_url: 'https://example.com/sample.pdf',
      description: 'In-depth study material on wave-particle duality, Schrödinger equation, and quantum phenomena.',
      subtopic: 'Quantum Physics'
    },
    {
      id: 6,
      title: 'Nuclear Physics',
      subject: 'Physics',
      class_level: 'Bachelor Third Year',
      author: 'Dr. Prakash Ghimire',
      upload_date: '2024-02-20',
      downloads: 89,
      file_url: 'https://example.com/sample.pdf',
      description: 'Detailed notes on nuclear structure, radioactivity, nuclear reactions, and elementary particles.',
      subtopic: 'Nuclear Physics'
    },
    {
      id: 7,
      title: 'Optics and Photonics',
      subject: 'Physics',
      class_level: 'Bachelor Second Year',
      author: 'Dr. Suman Karki',
      upload_date: '2024-03-18',
      downloads: 76,
      file_url: 'https://example.com/sample.pdf',
      description: 'Comprehensive notes on geometric optics, wave optics, interference, diffraction, and modern photonics.',
      subtopic: 'Optics'
    },
    {
      id: 8,
      title: 'Solid State Physics',
      subject: 'Physics',
      class_level: 'Bachelor Fourth Year',
      author: 'Prof. Ramesh Shrestha',
      upload_date: '2024-02-15',
      downloads: 102,
      file_url: 'https://example.com/sample.pdf',
      description: 'Detailed study material on crystal structures, lattice dynamics, electronic properties of solids, and semiconductor physics.',
      subtopic: 'Solid State Physics'
    },
    {
      id: 9,
      title: 'Relativity and Cosmology',
      subject: 'Physics',
      class_level: 'Masters',
      author: 'Dr. Pradeep Bhattarai',
      upload_date: '2024-01-25',
      downloads: 65,
      file_url: 'https://example.com/sample.pdf',
      description: 'Advanced notes on special and general relativity, spacetime curvature, and modern cosmological models.',
      subtopic: 'Relativity'
    },
    {
      id: 10,
      title: 'Atomic Physics',
      subject: 'Physics',
      class_level: 'Bachelor Third Year',
      author: 'Dr. Sarita Poudel',
      upload_date: '2024-02-10',
      downloads: 88,
      file_url: 'https://example.com/sample.pdf',
      description: 'Comprehensive notes on atomic structure, spectroscopy, and quantum mechanical models of atoms.',
      subtopic: 'Atomic Physics'
    },
    // Chemistry notes
    {
      id: 11,
      title: 'Organic Chemistry Fundamentals',
      subject: 'Chemistry',
      class_level: '+2 First Year',
      author: 'Dr. Hari Prasad',
      upload_date: '2024-03-05',
      downloads: 132,
      file_url: 'https://example.com/sample.pdf',
      description: 'Introduction to organic compounds, functional groups, and basic reaction mechanisms.',
      subtopic: 'Organic Chemistry'
    },
    {
      id: 12,
      title: 'Inorganic Chemistry',
      subject: 'Chemistry',
      class_level: '+2 Second Year',
      author: 'Prof. Sunita Sharma',
      upload_date: '2024-02-20',
      downloads: 95,
      file_url: 'https://example.com/sample.pdf',
      description: 'Comprehensive notes on periodic table, chemical bonding, and coordination compounds.',
      subtopic: 'Inorganic Chemistry'
    }
  ];

  useEffect(() => {
    // Simulate fetching data from Supabase
    setLoading(true);
    setTimeout(() => {
      // Filter notes by the current subject
      const filteredNotes = sampleNotes.filter(note => 
        note.subject.toLowerCase() === subject?.toLowerCase()
      );
      setNotes(filteredNotes);
      
      // Group notes by subtopic
      const subtopicMap = new Map<string, Note[]>();
      filteredNotes.forEach(note => {
        const subtopic = note.subtopic || 'General';
        if (!subtopicMap.has(subtopic)) {
          subtopicMap.set(subtopic, []);
        }
        subtopicMap.get(subtopic)?.push(note);
      });
      
      // Convert map to array of subtopic groups
      const subtopicGroups: SubtopicGroup[] = [];
      subtopicMap.forEach((notes, name) => {
        subtopicGroups.push({ name, notes });
      });
      
      setSubtopics(subtopicGroups);
      setLoading(false);
    }, 1000);

    // In a real app, you would fetch from Supabase like this:
    // const fetchNotes = async () => {
    //   try {
    //     const { data, error } = await supabase
    //       .from('notes')
    //       .select('*')
    //       .eq('subject', subject);
    //     
    //     if (error) throw error;
    //     if (data) {
    //       setNotes(data);
    //       
    //       // Group notes by subtopic
    //       const subtopicMap = new Map<string, Note[]>();
    //       data.forEach(note => {
    //         const subtopic = note.subtopic || 'General';
    //         if (!subtopicMap.has(subtopic)) {
    //           subtopicMap.set(subtopic, []);
    //         }
    //         subtopicMap.get(subtopic)?.push(note);
    //       });
    //       
    //       // Convert map to array of subtopic groups
    //       const subtopicGroups: SubtopicGroup[] = [];
    //       subtopicMap.forEach((notes, name) => {
    //         subtopicGroups.push({ name, notes });
    //       });
    //       
    //       setSubtopics(subtopicGroups);
    //     }
    //   } catch (error) {
    //     console.error('Error fetching notes:', error);
    //   } finally {
    //     setLoading(false);
    //   }
    // };
    // 
    // fetchNotes();
  }, [subject]);

  // Filter notes based on class level
  const filteredNotes = notes.filter(note => {
    return selectedClassLevel === 'all' || note.class_level === selectedClassLevel;
  });

  // Filter subtopics based on class level
  const filteredSubtopics = subtopics.map(group => {
    return {
      ...group,
      notes: group.notes.filter(note => 
        selectedClassLevel === 'all' || note.class_level === selectedClassLevel
      )
    };
  }).filter(group => group.notes.length > 0);

  const handleViewPdf = (note: Note) => {
    setViewingPdf(note);
  };

  const handleClosePdf = () => {
    setViewingPdf(null);
  };

  const handleDownload = (note: Note) => {
    // In a real app, this would download the PDF file
    alert(`Downloading ${note.title}`);
  };

  const toggleView = () => {
    setShowSubtopics(!showSubtopics);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <Link to="/notes" className="flex items-center text-blue-600 hover:underline mb-4">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to all notes
        </Link>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{subject} Notes</h1>
        <p className="text-gray-600">Browse and download {subject} study materials organized by class level</p>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <h2 className="text-xl font-semibold">Filter by Class Level</h2>
          <div className="flex items-center gap-4">
            <select
              className="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={selectedClassLevel}
              onChange={(e) => setSelectedClassLevel(e.target.value)}
            >
              {classLevels.map((level) => (
                <option key={level} value={level === 'All' ? 'all' : level}>
                  {level}
                </option>
              ))}
            </select>
            <button 
              onClick={toggleView}
              className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors"
            >
              {showSubtopics ? 'View by Class' : 'View by Subtopic'}
            </button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : showSubtopics ? (
        // View by Subtopics
        filteredSubtopics.length === 0 ? (
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No notes found</h3>
            <p className="text-gray-600">Try selecting a different class level or check back later</p>
          </div>
        ) : (
          <div className="space-y-10">
            {filteredSubtopics.map((group) => (
              <div key={group.name} className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-semibold mb-6 pb-2 border-b flex items-center">
                  <BookOpen className="h-5 w-5 mr-2 text-blue-600" />
                  {group.name}
                </h2>
                <div className="grid gap-6">
                  {group.notes.map((note) => (
                    <div key={note.id} className="border border-gray-100 p-5 rounded-lg hover:shadow-md transition-shadow">
                      <div className="flex flex-col md:flex-row justify-between">
                        <div className="mb-4 md:mb-0">
                          <div className="flex items-center mb-2">
                            <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                              {note.class_level}
                            </span>
                          </div>
                          <h3 className="text-xl font-semibold mb-2">{note.title}</h3>
                          {note.description && (
                            <p className="text-gray-700 mb-3">{note.description}</p>
                          )}
                          <p className="text-gray-600">Author: {note.author}</p>
                          <p className="text-gray-600">Uploaded: {note.upload_date}</p>
                          <p className="text-gray-600">{note.downloads} downloads</p>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <button 
                            onClick={() => handleViewPdf(note)}
                            className="flex items-center justify-center px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View PDF
                          </button>
                          <button 
                            onClick={() => handleDownload(note)}
                            className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        // View by Class
        filteredNotes.length === 0 ? (
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No notes found</h3>
            <p className="text-gray-600">Try selecting a different class level or check back later</p>
          </div>
        ) : (
          <div className="grid gap-6">
            {filteredNotes.map((note) => (
              <div key={note.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex flex-col md:flex-row justify-between">
                  <div className="mb-4 md:mb-0">
                    <div className="flex items-center mb-2">
                      <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium mr-2">
                        {note.class_level}
                      </span>
                      {note.subtopic && (
                        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                          {note.subtopic}
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{note.title}</h3>
                    {note.description && (
                      <p className="text-gray-700 mb-3">{note.description}</p>
                    )}
                    <p className="text-gray-600">Author: {note.author}</p>
                    <p className="text-gray-600">Uploaded: {note.upload_date}</p>
                    <p className="text-gray-600">{note.downloads} downloads</p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button 
                      onClick={() => handleViewPdf(note)}
                      className="flex items-center justify-center px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View PDF
                    </button>
                    <button 
                      onClick={() => handleDownload(note)}
                      className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {viewingPdf && (
        <PdfViewer 
          pdfUrl={viewingPdf.file_url} 
          title={viewingPdf.title} 
          onClose={handleClosePdf} 
        />
      )}

      <div className="mt-12 bg-blue-50 p-6 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">{subject} Subtopics</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {subtopics.map((group) => (
            <div key={group.name} className="bg-white p-4 rounded-md shadow hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-lg mb-2 flex items-center">
                <BookOpen className="h-4 w-4 mr-2 text-blue-600" />
                {group.name}
              </h3>
              <p className="text-sm text-gray-600 mb-3">{group.notes.length} notes available</p>
              <button 
                onClick={() => {
                  setShowSubtopics(true);
                  document.getElementById(group.name)?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-blue-600 text-sm font-medium hover:underline"
              >
                View all {group.name} notes →
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default SubjectDetail;